<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Prime
 * @author     OneDigital <hello@onedigital.vn>
 * @copyright  @2025 PRIME GROUP
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Prime\Component\Prime\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\CMS\Layout\FileLayout;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use \Prime\Component\Prime\Site\Helper\PrimeHelper;


/**
 * Methods supporting a list of Prime records.
 *
 * @since  1.0.0
 */
class TilesModel extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see    JController
	 * @since  1.0.0
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id',
				'state', 'a.state',
				'ordering', 'a.ordering',
				'created_by', 'a.created_by',
				'modified_by', 'a.modified_by',
				'tile', 'a.tile',
				'sku', 'a.sku',
				'description', 'a.description',
				'brand', 'a.brand',
				'language', 'a.language',
				'gallery', 'a.gallery',
				'design', 'a.design',
				'thickness', 'a.thickness',
				'image', 'a.image',
				'area', 'a.area',
				'effects', 'a.effects',
				'color', 'a.color',
				'type', 'a.type',
				'groutcolor', 'a.groutcolor',
				'variation', 'a.variation',
				'surface', 'a.surface',
				'facetile', 'a.facetile',
				'size', 'a.size',
				'alias', 'a.alias',
				'video', 'a.video',
				'live', 'a.live',
				'collection', 'a.collection',
			);
		}

		parent::__construct($config);
	}

	

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return  void
	 *
	 * @throws  Exception
	 *
	 * @since   1.0.0
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState('a.id', 'ASC');

		$app = Factory::getApplication();
		$list = $app->getUserState($this->context . '.list');

		$value = $app->getUserState($this->context . '.list.limit', $app->get('list_limit', 25));
		$list['limit'] = $value;
		
		$this->setState('list.limit', $value);

		$value = $app->input->get('limitstart', 0, 'uint');
		$this->setState('list.start', $value);

		$ordering  = $this->getUserStateFromRequest($this->context .'.filter_order', 'filter_order', 'a.id');
		$direction = strtoupper($this->getUserStateFromRequest($this->context .'.filter_order_Dir', 'filter_order_Dir', 'ASC'));
		
		if(!empty($ordering) || !empty($direction))
		{
			$list['fullordering'] = $ordering . ' ' . $direction;
		}

		$app->setUserState($this->context . '.list', $list);

		

		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);

		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);

			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  DatabaseQuery
	 *
	 * @since   1.0.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db    = $this->getDbo();
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
					$this->getState(
							'list.select', 'DISTINCT a.*'
					)
			);
		$query->from('`#__prime_tiles` AS a');
			
		// Join over the users for the checked out user.
		$query->select('uc.name AS uEditor');
		$query->join('LEFT', '#__users AS uc ON uc.id=a.checked_out');

		// Join over the created by field 'created_by'
		$query->join('LEFT', '#__users AS created_by ON created_by.id = a.created_by');

		// Join over the created by field 'modified_by'
		$query->join('LEFT', '#__users AS modified_by ON modified_by.id = a.modified_by');
		// Join over the foreign key 'brand'
		$query->select('`#__prime_brands_4126008`.`brand` AS brands_fk_value_4126008');
		$query->join('LEFT', '#__prime_brands AS #__prime_brands_4126008 ON #__prime_brands_4126008.`id` = a.`brand`');
		// Join over the foreign key 'design'
		$query->select('`#__prime_designs_4128066`.`title` AS designs_fk_value_4128066');
		$query->join('LEFT', '#__prime_designs AS #__prime_designs_4128066 ON #__prime_designs_4128066.`id` = a.`design`');
		// Join over the foreign key 'thickness'
		$query->select('`#__prime_thickness_4128072`.`thickness` AS thicknesses_fk_value_4128072');
		$query->join('LEFT', '#__prime_thickness AS #__prime_thickness_4128072 ON #__prime_thickness_4128072.`id` = a.`thickness`');
		// Join over the foreign key 'color'
		$query->select('`#__prime_colors_4128083`.`color` AS colors_fk_value_4128083');
		$query->join('LEFT', '#__prime_colors AS #__prime_colors_4128083 ON #__prime_colors_4128083.`id` = a.`color`');
		// Join over the foreign key 'type'
		$query->select('`#__prime_types_4128086`.`type` AS types_fk_value_4128086');
		$query->join('LEFT', '#__prime_types AS #__prime_types_4128086 ON #__prime_types_4128086.`id` = a.`type`');
		// Join over the foreign key 'groutcolor'
		$query->select('`#__prime_groutcolors_4128089`.`groutcolor` AS groutcolors_fk_value_4128089');
		$query->join('LEFT', '#__prime_groutcolors AS #__prime_groutcolors_4128089 ON #__prime_groutcolors_4128089.`id` = a.`groutcolor`');
		// Join over the foreign key 'variation'
		$query->select('`#__prime_variation_colors_4128092`.`variation` AS variationcolors_fk_value_4128092');
		$query->join('LEFT', '#__prime_variation_colors AS #__prime_variation_colors_4128092 ON #__prime_variation_colors_4128092.`id` = a.`variation`');
		// Join over the foreign key 'surface'
		$query->select('`#__prime_surfaces_4128095`.`surface` AS surfaces_fk_value_4128095');
		$query->join('LEFT', '#__prime_surfaces AS #__prime_surfaces_4128095 ON #__prime_surfaces_4128095.`id` = a.`surface`');
		// Join over the foreign key 'facetile'
		$query->select('`#__prime_faces_4128098`.`face` AS faces_fk_value_4128098');
		$query->join('LEFT', '#__prime_faces AS #__prime_faces_4128098 ON #__prime_faces_4128098.`id` = a.`facetile`');
		// Join over the foreign key 'size'
		$query->select('`#__prime_sizes_4128102`.`size` AS sizes_fk_value_4128102');
		$query->join('LEFT', '#__prime_sizes AS #__prime_sizes_4128102 ON #__prime_sizes_4128102.`id` = a.`size`');
			
		if (!Factory::getApplication()->getIdentity()->authorise('core.edit', 'com_prime'))
		{
			$query->where('a.state = 1');
		}
		else
		{
			$query->where('(a.state IN (0, 1))');
		}

        $lang = Factory::getApplication()->getLanguage()->getTag();
        if ($lang) {
            $query->where('a.language IN (' . $db->quote($lang) . ', ' . $db->quote('*') . ')');
        }
		
		//filters
		$app   	= Factory::getApplication();
		$input 	= $app->getInput();
		$checked_areas	= $input->getCmd('area', array());
		$checked_colors	= $input->getCmd('color', array());
		$checked_designs	= $input->getCmd('design', array());
		$checked_types	= $input->getCmd('type', array());
		$checked_sizes	= $input->getCmd('size', array());
		$checked_surfaces	= $input->getCmd('surface', array());
        $sku = $input->getString('sku');

        if (!empty($sku))
        {
            $query->where($db->quoteName('a.sku') . ' LIKE ' . $db->quote('%' . $db->escape($sku, true) . '%'));
        }
		//areas
		if(count($checked_areas)) {
			$where_areas = array();
			foreach($checked_areas AS $checked_area) {
				$where_areas[] = " ((a.area LIKE '%,".$checked_area.",%') OR (a.area LIKE '".$checked_area.",%') OR (a.area LIKE '%,".$checked_area."') OR (a.area LIKE '".$checked_area."'))";
			}
			$query->where("(".implode(" OR ", $where_areas).")");
		}
		//checked_colors
		if(count($checked_colors)) {
			$query->where(" a.color IN (".implode(", ", $checked_colors).")");
		}
		//checked_designs
		if(count($checked_designs)) {
			$query->where(" a.design IN (".implode(", ", $checked_designs).")");
		}
		//checked_types
		if(count($checked_types)) {
			$where_types = array();
			foreach($checked_types AS $checked_type) {
				$where_types[] = " ((a.type LIKE '%,".$checked_type.",%') OR (a.type LIKE '".$checked_type.",%') OR (a.type LIKE '%,".$checked_type."') OR (a.type LIKE '".$checked_type."'))";
			}
			$query->where("(".implode(" OR ", $where_types).")");
		}
		
		//checked_sizes
		if(count($checked_sizes)) {
			$query->where(" a.size IN (".implode(", ", $checked_sizes).")");
		}
		//checked_surfaces
		if(count($checked_surfaces)) {
			$query->where(" a.surface IN (".implode(", ", $checked_surfaces).")");
		}
		//echo $query;exit;
		/*
		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
			}
		}
			

		// Filtering brand
		$filter_brand = $this->state->get("filter.brand");

		if ($filter_brand)
		{
			$query->where("a.`brand` = '".$db->escape($filter_brand)."'");
		}

		// Filtering language

		// Filtering design
		$filter_design = $this->state->get("filter.design");

		if ($filter_design)
		{
			$query->where("a.`design` = '".$db->escape($filter_design)."'");
		}

		// Filtering thickness
		$filter_thickness = $this->state->get("filter.thickness");

		if ($filter_thickness)
		{
			$query->where("a.`thickness` = '".$db->escape($filter_thickness)."'");
		}

		// Filtering size
		$filter_size = $this->state->get("filter.size");

		if ($filter_size)
		{
			$query->where("a.`size` = '".$db->escape($filter_size)."'");
		}
		
		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', 'a.id');
		$orderDirn = $this->state->get('list.direction', 'ASC');

		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}
		*/
		
		return $query;
	}

	/**
	 * Method to get an array of data items
	 *
	 * @return  mixed An array of data on success, false on failure.
	 */
	public function getItems()
	{
		$items = parent::getItems();
		
		foreach ($items as $item)
		{

			if (isset($item->brand))
			{

				$values    = explode(',', $item->brand);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = $this->getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__prime_brands_4126008`.`brand`')
						->from($db->quoteName('#__prime_brands', '#__prime_brands_4126008'))
						->where($db->quoteName('#__prime_brands_4126008.id') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->brand;
					}
				}

				$item->brand = !empty($textValue) ? implode(', ', $textValue) : $item->brand;
			}


			if (isset($item->design))
			{

				$values    = explode(',', $item->design);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = $this->getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__prime_designs_4128066`.`title`')
						->from($db->quoteName('#__prime_designs', '#__prime_designs_4128066'))
						->where($db->quoteName('#__prime_designs_4128066.id') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->title;
					}
				}

				$item->design = !empty($textValue) ? implode(', ', $textValue) : $item->design;
			}


			if (isset($item->thickness))
			{

				$values    = explode(',', $item->thickness);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = $this->getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__prime_thickness_4128072`.`thickness`')
						->from($db->quoteName('#__prime_thickness', '#__prime_thickness_4128072'))
						->where($db->quoteName('#__prime_thickness_4128072.id') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->thickness;
					}
				}

				$item->thickness = !empty($textValue) ? implode(', ', $textValue) : $item->thickness;
			}


			if (isset($item->area))
			{
				$values    = explode(',', $item->area);
				$textValue = array();

				foreach ($values as $value)
				{
					if (!empty($value))
					{
						$db    = $this->getDbo();
						$query = "SELECT id, area  FROM #__prime_areas
 WHERE id = '$value' ";

						$db->setQuery($query);
						$results = $db->loadObject();

						if ($results)
						{
							$textValue[] = $results->area;
						}
					}
				}

				$item->area = !empty($textValue) ? implode(', ', $textValue) : $item->area;
			}

			if (isset($item->effects))
			{
				$values    = explode(',', $item->effects);
				$textValue = array();

				foreach ($values as $value)
				{
					if (!empty($value))
					{
						$db    = $this->getDbo();
						$query = "SELECT id, effect FROM #__prime_effects WHERE id = '$value' ";

						$db->setQuery($query);
						$results = $db->loadObject();

						if ($results)
						{
							$textValue[] = $results->effect;
						}
					}
				}

				$item->effects = !empty($textValue) ? implode(', ', $textValue) : $item->effects;
			}

			if (isset($item->color))
			{

				$values    = explode(',', $item->color);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = $this->getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__prime_colors_4128083`.`color`')
						->from($db->quoteName('#__prime_colors', '#__prime_colors_4128083'))
						->where($db->quoteName('#__prime_colors_4128083.id') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->color;
					}
				}

				$item->color = !empty($textValue) ? implode(', ', $textValue) : $item->color;
			}


			if (isset($item->type))
			{

				$values    = explode(',', $item->type);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = $this->getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__prime_types_4128086`.`type`')
						->from($db->quoteName('#__prime_types', '#__prime_types_4128086'))
						->where($db->quoteName('#__prime_types_4128086.id') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->type;
					}
				}

				$item->type = !empty($textValue) ? implode(', ', $textValue) : $item->type;
			}


			if (isset($item->groutcolor))
			{

				$values    = explode(',', $item->groutcolor);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = $this->getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__prime_groutcolors_4128089`.`groutcolor`')
						->from($db->quoteName('#__prime_groutcolors', '#__prime_groutcolors_4128089'))
						->where($db->quoteName('#__prime_groutcolors_4128089.id') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->groutcolor;
					}
				}

				$item->groutcolor = !empty($textValue) ? implode(', ', $textValue) : $item->groutcolor;
			}


			if (isset($item->variation))
			{

				$values    = explode(',', $item->variation);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = $this->getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__prime_variation_colors_4128092`.`variation`')
						->from($db->quoteName('#__prime_variation_colors', '#__prime_variation_colors_4128092'))
						->where($db->quoteName('#__prime_variation_colors_4128092.id') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->variation;
					}
				}

				$item->variation = !empty($textValue) ? implode(', ', $textValue) : $item->variation;
			}


			if (isset($item->surface))
			{

				$values    = explode(',', $item->surface);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = $this->getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__prime_surfaces_4128095`.`surface`')
						->from($db->quoteName('#__prime_surfaces', '#__prime_surfaces_4128095'))
						->where($db->quoteName('#__prime_surfaces_4128095.id') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->surface;
					}
				}

				$item->surface = !empty($textValue) ? implode(', ', $textValue) : $item->surface;
			}


			if (isset($item->facetile))
			{

				$values    = explode(',', $item->facetile);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = $this->getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__prime_faces_4128098`.`face`')
						->from($db->quoteName('#__prime_faces', '#__prime_faces_4128098'))
						->where($db->quoteName('#__prime_faces_4128098.id') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->face;
					}
				}

				$item->facetile = !empty($textValue) ? implode(', ', $textValue) : $item->facetile;
			}


			if (isset($item->size))
			{

				$values    = explode(',', $item->size);
				$textValue = array();

				foreach ($values as $value)
				{
					$db    = $this->getDbo();
					$query = $db->getQuery(true);
					$query
						->select('`#__prime_sizes_4128102`.`size`')
						->from($db->quoteName('#__prime_sizes', '#__prime_sizes_4128102'))
						->where($db->quoteName('#__prime_sizes_4128102.id') . ' = '. $db->quote($db->escape($value)));

					$db->setQuery($query);
					$results = $db->loadObject();

					if ($results)
					{
						$textValue[] = $results->size;
					}
				}

				$item->size = !empty($textValue) ? implode(', ', $textValue) : $item->size;
			}

		}

		return $items;
	}

	/**
	 * Overrides the default function to check Date fields format, identified by
	 * "_dateformat" suffix, and erases the field if it's not correct.
	 *
	 * @return void
	 */
	protected function loadFormData()
	{
		$app              = Factory::getApplication();
		$filters          = $app->getUserState($this->context . '.filter', array());
		$error_dateformat = false;

		foreach ($filters as $key => $value)
		{
			if (strpos($key, '_dateformat') && !empty($value) && $this->isValidDate($value) == null)
			{
				$filters[$key]    = '';
				$error_dateformat = true;
			}
		}

		if ($error_dateformat)
		{
			$app->enqueueMessage(Text::_("COM_PRIME_SEARCH_FILTER_DATE_FORMAT"), "warning");
			$app->setUserState($this->context . '.filter', $filters);
		}

		return parent::loadFormData();
	}

	/**
	 * Checks if a given date is valid and in a specified format (YYYY-MM-DD)
	 *
	 * @param   string  $date  Date to be checked
	 *
	 * @return bool
	 */
	private function isValidDate($date)
	{
		$date = str_replace('/', '-', $date);
		return (date_create($date)) ? Factory::getDate($date)->format("Y-m-d") : null;
	}
}